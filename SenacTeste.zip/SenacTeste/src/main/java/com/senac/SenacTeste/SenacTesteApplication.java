package com.senac.SenacTeste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenacTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenacTesteApplication.class, args);
	}

}
