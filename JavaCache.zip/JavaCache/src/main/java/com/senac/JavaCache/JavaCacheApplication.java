package com.senac.JavaCache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCacheApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaCacheApplication.class, args);
	}

}
